Thanks a lot to Victor Andreyenkov for creating these
refined versions of Christopher Bolin's icons!
